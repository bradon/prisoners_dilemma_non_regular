package edu.monash.bthal2.repeatedPD.DPDA.Exception;

public class NoTransitionException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6548507845383935143L;

}
