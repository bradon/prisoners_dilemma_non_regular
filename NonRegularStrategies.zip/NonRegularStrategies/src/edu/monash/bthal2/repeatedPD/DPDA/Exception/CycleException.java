package edu.monash.bthal2.repeatedPD.DPDA.Exception;

public class CycleException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 9214208135616110911L;

}
