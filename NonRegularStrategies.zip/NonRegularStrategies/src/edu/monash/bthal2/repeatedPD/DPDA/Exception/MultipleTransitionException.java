package edu.monash.bthal2.repeatedPD.DPDA.Exception;

public class MultipleTransitionException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8567929362237848089L;

}
